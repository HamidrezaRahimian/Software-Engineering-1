package Aufagbe2.SingleResopnibility;



public enum PaymentMethod {
    CASH,
    CARD,
    APPLE_PAY,
    GOOGLE_PAY
}

