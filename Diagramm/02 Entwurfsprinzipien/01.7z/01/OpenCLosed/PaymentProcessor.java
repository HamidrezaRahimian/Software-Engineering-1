package Aufagbe2.OpenCLosed;



public interface PaymentProcessor {
    String processPayment(double totalAmount);
}

