package Aufagbe2.InterfaceSegregationPrinciple;

public interface IDiscountable {
    void applyDiscount(double percentage);
}
