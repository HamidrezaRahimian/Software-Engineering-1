package Aufagbe2.InterfaceSegregationPrinciple;

public interface IOrdering {
    void orderItem(String item);
}
