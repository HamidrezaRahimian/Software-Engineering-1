package Aufagbe2.InterfaceSegregationPrinciple;

public interface ISelectionOperations {
    void cancelSelection(String item);
}
