package Aufagbe2.InterfaceSegregationPrinciple;

public interface IReviewOrder {
    void reviewOrder();
}
