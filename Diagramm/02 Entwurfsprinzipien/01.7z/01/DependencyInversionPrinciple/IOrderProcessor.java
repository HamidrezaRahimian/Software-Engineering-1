package Aufagbe2.DependencyInversionPrinciple;

public interface IOrderProcessor {
    void processOrder(String item, double price);
}
