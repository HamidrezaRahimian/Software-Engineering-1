package Aufagbe2.DependencyInversionPrinciple;

public interface IItemSelector {
    void selectItem(String item);
}
