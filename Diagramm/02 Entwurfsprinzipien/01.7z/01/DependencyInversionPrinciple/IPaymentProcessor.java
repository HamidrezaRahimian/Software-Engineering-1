package Aufagbe2.DependencyInversionPrinciple;

public interface IPaymentProcessor {

    void processPayment(double amount);
}
