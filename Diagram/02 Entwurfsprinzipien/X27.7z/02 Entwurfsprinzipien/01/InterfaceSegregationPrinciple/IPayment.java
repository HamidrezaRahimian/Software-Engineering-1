package Aufagbe2.InterfaceSegregationPrinciple;

public interface IPayment {
    void processPayment(double amount);
}
