package Aufagbe2.InterfaceSegregationPrinciple;

public interface ISelection {
    void selectItem(String item);
}
